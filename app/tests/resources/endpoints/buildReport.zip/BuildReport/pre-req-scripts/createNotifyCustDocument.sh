#!/bin/bash
unset http_proxy
bucketName=com.amdocs.digital.ms.ordernotification.notifycustomer
auth=Administrator:Administrator
server=`kubectl --kubeconfig ${1} get svc couchbase-service-5 -o jsonpath='{.spec.externalName}'`

QUERY='''INSERT INTO `com.amdocs.digital.ms.ordernotification.notifycustomer` ( KEY, VALUE ) VALUES (
    "OrderSubmitted_SMS",
  {
  "messageName": "OrderSubmitted",
  "communicationType": "SMS",
  "keyPathMap": {
    "OrderSubmitted_SMS": ""
  },
  "subject": "Order successfully submitted",
  "key": {
    "sequence": "SMS",
    "keyString": "OrderSubmitted_SMS",
    "entityType": "OrderSubmitted"
  },
  "content": [
    {
      "value": "Your Order with reference O10001 has been successfully submitted on 7th May 2018 at 11:00AM.",
      "key": "en_US"
    },
    {
      "value": "Votre",
      "key": "fr_CA"
    }
  ]
}
) '''

echo "[INFO] Inserting new document to bucket $bucketName and server $server"
curl -v http://${server}:8093/query/service -d "statement=${QUERY}" -u $auth

if [ $? -eq 0 ]; then
    echo "[INFO] Successfully inserted new document to bucket $bucketName and server $server"
else
    echo "[ERROR] Failed to insert new document to bucket $bucketName and server $server"
fi