#!/bin/bash

couchbaseServer=`kubectl --kubeconfig ${1} get svc couchbase-service-5 -o jsonpath='{.spec.externalName}'`
cbUser="Administrator"
cbPassword="Administrator"
bucketToFlush="com.amdocs.digital.ms.orderexecution.handleorder"

curl -vX POST -u ${cbUser}:${cbPassword} -d 'flushEnabled=1' http://${couchbaseServer}:8091/pools/default/buckets/${bucketToFlush} || :
curl -vX POST -u ${cbUser}:${cbPassword} http://${couchbaseServer}:8091/pools/default/buckets/${bucketToFlush}/controller/doFlush || :

echo "Bucket ${bucketToFlush} Flushed."